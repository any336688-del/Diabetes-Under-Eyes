ارفع هذا المحتوى إلى GitHub ثم شغّل Actions لتحصل على APK.
أو افتح المجلد في Android Studio واختر Build > Build APK.
